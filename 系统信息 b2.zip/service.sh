#!/bin/bash

# 脚本路径和配置
MODDIR=${0%/*}
CONFIG_FILE="$MODDIR/config.prop"
HISTORY_FILE="$MODDIR/history.log"
LOG_FILE="$MODDIR/device_info.log"

# 加载配置
source "$CONFIG_FILE"

# 日志函数
log_message() {
    echo "$(date '+%Y-%m-%d %H:%M:%S') - $1" >> "$LOG_FILE"
}

# 获取设备信息
get_device_info() {
    local battery_level=$(dumpsys battery | grep level | cut -d: -f2 | tr -d ' ')
    local battery_temp=$(echo "scale=1; $(dumpsys battery | grep temperature | cut -d: -f2 | tr -d ' ') / 10" | bc)
    local model=$(getprop ro.product.model)
    local android_version=$(getprop ro.build.version.release)
    
    local network_info=$(get_network_info)
    local memory_usage=$(get_memory_usage)
    local storage_usage=$(get_storage_usage)
    local cpu_usage=$(get_cpu_usage)
    local app_counts=$(get_app_counts)

    cat << EOF
# 设备信息 - $(date '+%Y-%m-%d %H:%M:%S')

* 电池电量: ${battery_level}%
* 电池温度: ${battery_temp}°C
* 设备型号: ${model}
* Android版本: ${android_version}
$network_info
* 内存使用详情: $memory_usage
* 存储使用详情: $storage_usage
* CPU使用率: ${cpu_usage}%
$app_counts

EOF
}

# 获取网络信息
get_network_info() {
    local connection_type="无连接"
    local wifi_name=""

    if ping -c 1 -W 1 8.8.8.8 >/dev/null 2>&1; then
        if dumpsys connectivity | grep -q "WIFI.*CONNECTED"; then
            connection_type="WiFi"
            wifi_name=$(dumpsys wifi | grep "mWifiInfo" | grep "SSID" | cut -d'"' -f2)
        else
            connection_type="移动数据"
        fi
    fi

    cat << EOF
* 网络连接: $connection_type
* WiFi名称: ${wifi_name:-N/A}
EOF
}

# 获取内存使用情况
get_memory_usage() {
    local meminfo=$(cat /proc/meminfo)
    local total=$(echo "$meminfo" | awk '/MemTotal:/ {print $2}')
    local available=$(echo "$meminfo" | awk '/MemAvailable:/ {print $2}')
    local used=$((total - available))
    
    local total_gb=$(echo "scale=2; $total / 1048576" | bc)
    local used_gb=$(echo "scale=2; $used / 1048576" | bc)
    local available_gb=$(echo "scale=2; $available / 1048576" | bc)
    local usage_percent=$(echo "scale=1; $used * 100 / $total" | bc)

    printf "总计: %.2fG, 已用: %.2fG, 可用: %.2fG, 使用率: %.1f%%" $total_gb $used_gb $available_gb $usage_percent
}

# 获取存储使用情况
get_storage_usage() {
    local storage_info=$(df -k /data)
    local total=$(echo "$storage_info" | awk 'NR==2 {print $2}')
    local used=$(echo "$storage_info" | awk 'NR==2 {print $3}')
    local available=$(echo "$storage_info" | awk 'NR==2 {print $4}')
    
    local total_gb=$(echo "scale=2; $total / 1048576" | bc)
    local used_gb=$(echo "scale=2; $used / 1048576" | bc)
    local available_gb=$(echo "scale=2; $available / 1048576" | bc)
    local usage_percent=$(echo "scale=1; $used * 100 / $total" | bc)

    printf "总计: %.2fG, 已用: %.2fG, 可用: %.2fG, 使用率: %.1f%%" $total_gb $used_gb $available_gb $usage_percent
}

# 获取CPU使用率
get_cpu_usage() {
    top -bn1 | grep "^CPU:" | awk '{print $2}' | cut -d'%' -f1
}

# 获取应用计数
get_app_counts() {
    local dumpsys_output=$(dumpsys activity processes)
    local foreground=$(echo "$dumpsys_output" | grep -c "Proc # [0-9]*: fore")
    local visible=$(echo "$dumpsys_output" | grep -c "Proc # [0-9]*: vis")
    local service=$(echo "$dumpsys_output" | grep -c "Proc # [0-9]*: svc")
    local background=$(echo "$dumpsys_output" | grep -c "Proc # [0-9]*: bak")
    local cached=$(echo "$dumpsys_output" | grep -c "Proc # [0-9]*: cch")
    local running=$((foreground + visible + service))

    cat << EOF
* 正在运行的应用数: $running (前台: $foreground, 可见: $visible, 服务: $service)
* 后台应用数: $background
* 缓存的应用数: $cached
EOF
}

# 清理历史记录
clear_history() {
    if [ "$clear_history_days" -eq -1 ]; then
        return
    fi

    if [ -f "$HISTORY_FILE" ]; then
        local file_age=$(( ($(date +%s) - $(date +%s -r "$HISTORY_FILE")) / 86400 ))
        if [ $file_age -ge $clear_history_days ]; then
            > "$HISTORY_FILE"
            log_message "历史记录已清空（文件存在 $file_age 天）"
        fi
    fi
}

# 输出信息
output_info() {
    local current_info=$(get_device_info)
    
    if [ "$overwrite" = "true" ]; then
        echo "$current_info" > "$output_dir/$output_file"
        log_message "已覆盖写入设备信息到 $output_dir/$output_file"
    else
        echo "$current_info" >> "$output_dir/$output_file"
        log_message "已追加设备信息到 $output_dir/$output_file"
    fi
    
    if [ "$keep_history" = "true" ]; then
        clear_history
        echo "$current_info" | sed 's/^# //' | sed 's/^\* //' >> "$HISTORY_FILE"
        log_message "已更新历史记录"
    fi
}

# 主循环
main_loop() {
    log_message "服务已启动"
    while true; do
        output_info
        sleep $((interval * 60))
    done
}

# 延迟10秒后启动主循环
(sleep 10 && main_loop) &